Dataset部分包含了实际数据集

可以使用extractData获取对应测试集和训练集

对于完成图像量化部分的同学,可以再写一份代码来保存图像

数据集来源: [Amotica/SPOTS-10](https://github.com/Amotica/SPOTS-10)

